rm 00000bxvvs.zip
echo FUCK THIS STUPID WINDOWS OPERATING SYSTEM
echo Resource pack SHA-1 hash: $(shasum 00000bxvvs.zip | cut -c-40)

$SHELL