# JustRPG Resource Pack

Resource pack hub for JustRPG. Changes made to the repository are automatically
 updated on the server.

## Contributing

Open a pull request with your changes. Be sure to run `zip.sh` after making changes
 so that the `pack.zip` file updates accordingly.